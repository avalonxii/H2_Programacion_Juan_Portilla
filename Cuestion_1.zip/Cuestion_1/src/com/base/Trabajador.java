package com.base;

public class Trabajador {
	//atributos
	private String nombre;
	private String ciudad;
	private double salarioBruto;
	private boolean contratoTemporal;
	
	
	//constructor
	public Trabajador(String nombre, String ciudad, double salarioBruto, boolean contratoTemporal) {
		this.nombre = nombre;
		this.ciudad = ciudad;
		this.salarioBruto = salarioBruto;
		this.contratoTemporal = contratoTemporal;
	}
	
	
	//------------Getter / Setter-------------//
	//nombre
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	
	//ciudad
	public String getCiudad() {
		return ciudad;
	}
	public void setCiudad(String ciudad) {
		this.ciudad = ciudad;
	}
	
	//salario bruto
	public double getSalarioBruto() {
		return salarioBruto;
	}
	public void setSalarioBruto(double salarioBruto) {
		this.salarioBruto = salarioBruto;
	}
	
	//contrato
	public boolean isContratoTemporal() {
		return contratoTemporal;
	}
	public void setContratoTemporal(boolean contratoTemporal) {
		this.contratoTemporal = contratoTemporal;
	}
	
	//------------Metodos-------------//
	public void fichaTrabajador() {
		System.out.print(this.nombre+"-"+this.ciudad+"-"+ this.salarioBruto);
		
		if(contratoTemporal)
			System.out.println("-contrato temporal");
		else
			System.out.println("-NO contrato temporal");
		
		System.out.println("");
	}
	

	
}//cierre clase trabajdor
