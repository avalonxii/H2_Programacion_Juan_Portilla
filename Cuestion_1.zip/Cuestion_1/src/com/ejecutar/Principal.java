package com.ejecutar;

import com.base.Trabajador;

public class Principal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Trabajador trabajador = new Trabajador("juan","madrid",1300.67,false);
		Trabajador trabajador1 = new Trabajador("pepe","sevilla",1200.67,true);
		
		//comprobar las ficas de los trabajadores antes de la modificacion
		System.out.println("ANTES:");
		trabajador.fichaTrabajador();
		trabajador1.fichaTrabajador();
		
		//modificar atributos (mediante setters)
		trabajador.setNombre("sebas");
		trabajador1.setCiudad("barcelona");
		trabajador.setSalarioBruto(1400);
		trabajador1.setContratoTemporal(false);
	
		//comprobar las ficas de los trabajadores despues de la modificacion
		System.out.println("DESPUES	:");
		trabajador.fichaTrabajador();
		trabajador1.fichaTrabajador();
		
		//Obtener los datos almacenados en los atributos(mediante getters)
		System.out.println("GETTERS:");
		double suma = trabajador.getSalarioBruto() + trabajador1.getSalarioBruto();
		System.out.println("suma salarios:"+suma);
		System.out.println("ciudad trabajado: "+trabajador.getCiudad());
		System.out.println("nombre trabajador1: "+trabajador1.getNombre());
	}//cierre main
	
}//cierre clase Principal
