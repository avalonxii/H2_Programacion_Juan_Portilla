
//para que una clase no pueda ser instanciada debe ser una clase abstracta
public abstract class Padre {
	//atributos
	private String nombre;
	private int edad;
	
	//constructor de la clase padre
	public Padre(String nombre, int edad) {
		this.nombre=nombre;
		this.edad=edad;
	}
	
	//getters / setters 
	
	    //Nombre------------------------------------
	public String getNombre() {
		return nombre;
	}
	
	public void setNombre(String nombre) {
		this.nombre=nombre;
	}
	
        //Edad--------------------------------------	
	public int getEdad() {
		return edad;
	}

	public void setEdad(int edad) {
		this.edad = edad;
	}

	//metodos
	public void saludar() {
		System.out.println("Hola, soy el padre");
	}
}//cierre clase
