public class Ejecutar {
	public static void main(String[] args) {
		
		Hija hija=new Hija("Laura",19);
		hija.saludar();
		
		hija.setEdad(23);
		System.out.println(hija.getEdad());
	
	}
}
