
public class Hija extends Padre{

	public Hija(String nombre, int edad) {
		super(nombre, edad);
		// TODO Auto-generated constructor stub
	}

	//sobreescritura-->Es la forma por la cual una clase que hereda puede re-definir los m�todos de su clase Padre
	public void saludar() {
		System.out.println("Hola, soy la hija");
	}
}
