package com.base;

public class Vehiculos {
	//Atributos
	protected String matricula;
	protected String marca;
	protected String modelo;
	
	//constructor
	public Vehiculos(String matricula, String marca, String modelo) {
		this.matricula = matricula;
		this.marca = marca;
		this.modelo = modelo;
	}

	
	//metodos
	public void mostrarDatos() {
		System.out.println("Matriculo: "+matricula+
							"\nMarca: "+marca+
							"\nModelo: "+modelo);
	}	
	
}//cierre clase
