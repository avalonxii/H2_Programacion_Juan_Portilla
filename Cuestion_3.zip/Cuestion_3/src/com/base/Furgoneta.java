package com.base;

public class Furgoneta extends Vehiculos{
	
	private  int carga;

	//constructos
	public Furgoneta(String matricula, String marca, String modelo, int carga) {
		super(matricula, marca, modelo);
		this.carga = carga;
	}
	
	//getter / setter
	public int getCarga() {
		return carga;
	}

	public void setCarga(int carga) {
		this.carga = carga;
	}
	
	//metodo sobreescrito
	public void mostrarDatos() {
		System.out.println("Matriculo: "+matricula+
							"\nMarca: "+marca+
							"\nModelo: "+modelo+ 
							"\nCarga: "+carga);
	}
}
