package com.ejecutar;

import com.base.*;

public class Principal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Vehiculos misVehiculos[] =new Vehiculos[3];
		
		/*en una relacion tipo herencia , un objeto superClase puede
		 * almaceanar un bojeto de cualquiera de sus subclase.
		 * 
		 * Esto singinifa que la clase padre(superClase) es compatible con los
		 * objetos que derivan de ella , pero no al reves.*/
		misVehiculos[0]= new Vehiculos("1265A","Seat","P8");
		misVehiculos[1]= new Turismo("5635B","Seat","P8",4);
		misVehiculos[2]= new Furgoneta("3425C","Seat","P8",89);
	}

}
